const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');

const app = express();
const PORT = process.env.PORT || 5050; // Modificăm PORT aici pentru a asculta pe portul 5050
const uri = "mongodb+srv://vacarumarta:<familiamea>@cluster0.hkdefsi.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

// MongoDB client
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

// Middleware
app.use(express.json());

// Connect to MongoDB
async function connectMongoDB() {
  try {
    await client.connect();
    console.log("Connected to MongoDB");
  } catch (error) {
    console.error("Failed to connect to MongoDB:", error);
    process.exit(1);
  }
}
connectMongoDB();

// Routes
app.get("/employees", async (req, res) => {
  try {
    const collection = client.db("Brutarie").collection("angajati"); 
    const employees = await collection.find({}).toArray();
    res.json(employees);
  } catch (error) {
    console.error("Error fetching employees:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.get("/employees/:employeeId/goals", async (req, res) => {
  try {
    const { employeeId } = req.params;
    const collection = client.db("Brutarie").collection("employees"); 
    const employee = await collection.findOne({ _id: ObjectId(employeeId) });
    res.json(employee.goals);
  } catch (error) {
    console.error("Error fetching goals for employee:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.get("/employees/:employeeId/absences", async (req, res) => {
  try {
    const { employeeId } = req.params;
    const collection = client.db("Brutarie").collection("employees"); 
    const employee = await collection.findOne({ _id: ObjectId(employeeId) });
    res.json(employee.absenta);
  } catch (error) {
    console.error("Error fetching absences for employee:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.get("/bakery/:bakeryId/products", async (req, res) => {
  try {
    const { bakeryId } = req.params;
    const collection = client.db("Brutarie").collection("produse");
    const products = await collection.find({ firma: ObjectId(bakeryId) }).toArray();
    res.json(products);
  } catch (error) {
    console.error("Error fetching products for bakery:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Other routes (addEmployee, editEmployee, deleteEmployee, etc.) can be implemented similarly

// Start server
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
