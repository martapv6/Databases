import './App.css';
import React from 'react';
import Teams from './pages/Teams';

function App() {
  return(
    <div>
      <Teams/>
    </div>
)
}

export default App;
