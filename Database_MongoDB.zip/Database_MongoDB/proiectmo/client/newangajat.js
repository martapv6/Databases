import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';

function NewEmployeeForm() {
    const [employeeName, setEmployeeName] = useState('');
    const [employeePosition, setEmployeePosition] = useState('');

    const location = useLocation();
    const { bakeryId } = location.state;

    const handleSubmit = (event) => {
        event.preventDefault();

        // Trimiteți o cerere POST către backend-ul dvs. pentru a adăuga noul angajat
        fetch('http://localhost:5050/addEmployee', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: employeeName,
                position: employeePosition,
                bakeryId: bakeryId
            })
        })
        .then(response => {
            if (response.ok) {
                console.log('Employee added successfully');
                window.history.back();
            } else {
                console.error('Failed to add employee');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    };

    return (
        <div className="container">
            <h2>Add Employee</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="employeeName" className="form-label">Employee Name</label>
                    <input type="text" className="form-control" id="employeeName" value={employeeName} onChange={(e) => setEmployeeName(e.target.value)} />
                </div>
                <div className="mb-3">
                    <label htmlFor="employeePosition" className="form-label">Employee Position</label>
                    <input type="text" className="form-control" id="employeePosition" value={employeePosition} onChange={(e) => setEmployeePosition(e.target.value)} />
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </div>
    );
}

export default NewEmployeeForm;
