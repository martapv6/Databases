import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

function EditEmployeeForm() {
    const [employeeName, setEmployeeName] = useState('');
    const [employeePosition, setEmployeePosition] = useState('');

    const location = useLocation();
    const { employeeDataToEdit } = location.state;

    useEffect(() => {
        if (employeeDataToEdit) {
            setEmployeeName(employeeDataToEdit.name);
            setEmployeePosition(employeeDataToEdit.position);
        }
    }, [employeeDataToEdit]);

    const handleSubmit = (event) => {
        event.preventDefault();

        // Trimiteți o cerere PATCH către backend-ul dvs. pentru a edita angajatul
        fetch(`http://localhost:5050/getemployees/${employeeDataToEdit._id}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                newName: employeeName,
                newPosition: employeePosition
            })
        })
        .then(response => {
            if (response.ok) {
                console.log('Employee edited successfully');
                window.history.back();
            } else {
                console.error('Failed to edit employee');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    };

    return (
        <div className="container">
            <h2>Edit Employee</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="employeeName" className="form-label">Employee Name</label>
                    <input type="text" className="form-control" id="employeeName" value={employeeName} onChange={(e) => setEmployeeName(e.target.value)} />
                </div>
                <div className="mb-3">
                    <label htmlFor="employeePosition" className="form-label">Employee Position</label>
                    <input type="text" className="form-control" id="employeePosition" value={employeePosition} onChange={(e) => setEmployeePosition(e.target.value)} />
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </div>
    );
}

export default EditEmployeeForm;
