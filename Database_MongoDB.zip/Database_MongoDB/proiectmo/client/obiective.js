import React, { useState, useEffect } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function EmployeeGoals() {
    const [goals, setGoals] = useState([]);

    const { employeeId } = useParams();

    const location = useLocation();
    const { employeeNameToTransfer } = location.state;

    useEffect(() => {
        // Fetch data from API
        fetch(`http://localhost:5050/getEmployeeGoals/${employeeId}`, {
            method: 'GET'
        })
        .then(response => response.json())
        .then(goals => setGoals(goals))
        .catch(error => console.error('Error fetching data:', error));
    }, []);

    return (
        <div>
            <h2>Goals of {employeeNameToTransfer}</h2>
            <table className="table">
                <thead>
                    <tr>
                        <th>Gameweek</th>
                        <th>Minute</th>
                    </tr>
                </thead>
                <tbody>
                    {goals.map(item => (
                        <tr key={item._id}>
                            <td>{item.gameweek}</td>
                            <td>{item.minute}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default EmployeeGoals;
