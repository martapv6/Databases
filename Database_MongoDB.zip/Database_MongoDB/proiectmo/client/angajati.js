import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

function Employees(){
    const [employees, setEmployees] = useState([]);
    const { bakeryId } = useParams();

    useEffect(() => {
        // Fetch data from API
        fetch(`http://localhost:5050/getEmployees/${bakeryId}`, {
            method: 'GET'
        })
        .then(response => response.json())
        .then(employees => setEmployees(employees))
        .catch(error => console.error('Error fetching data:', error));
    }, []);

    const handleDelete = (employeeId) => {
        // Send DELETE request to backend
        fetch(`http://localhost:5050/deleteEmployee/${employeeId}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.ok) {
                setEmployees(employees.filter(employee => employee._id !== employeeId));
            }
        })
        .catch(error => console.error('Error deleting employee:', error));
    };

    return(
        <div>
            <h2>Employees</h2>
            <Link to="/">
                <button type="button" className="btn btn-primary">Back</button>
            </Link>
            <Link to={`/addEmployee`} state={{bakeryId: bakeryId}}>
                <button type="button" className="btn btn-primary">Add Employee</button>
            </Link>
            <table className="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Actions</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map(employee => (
                        <tr key={employee._id}>
                            <td>{employee.name}</td>
                            <td>{employee.position}</td>
                            <td>
                                <button className="btn btn-danger" onClick={() => handleDelete(employee._id)}>Delete</button>
                                <Link to={`/editEmployee/${employee._id}`} state={{ employeeDataToEdit: employee }}>
                                    <button className="btn btn-primary ml-2">Edit</button>
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

export default Employees;
