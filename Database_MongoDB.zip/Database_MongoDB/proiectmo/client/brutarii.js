import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';

function Bakeries(){
    const [bakeries, setBakeries] = useState([]);

    useEffect(() => {
        // Fetch data from API
        fetch('http://localhost:5050/getBakeries', {
            method: 'GET'
        })
        .then(response => response.json())
        .then(bakeries => setBakeries(bakeries))
        .catch(error => console.error('Error fetching data:', error));
    }, []);

    return(
        <div>
            <h2>My Bakeries</h2>
            <table className="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {bakeries.map(bakery => (
                        <tr key={bakery._id}>
                            <td>{bakery.name}</td>
                            <td>{bakery.location}</td>
                            <td>
                                <Link to={`/employees/${bakery._id}`} state={{ bakeryNameToTransfer: bakery.name }}>
                                    View Employees
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

export default Bakeries;
