import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import Bakery from './pages/Bakery';
import NewEmployeeForm from './pages/NewEmployeeForm';
import EditEmployeeForm from './pages/EditEmployeeForm';
import EmployeeDetails from './pages/EmployeeDetails';

const router = createBrowserRouter([
  {
    path: "/",
    element: <App/>
  },
  {
    path: "/bakery",
    element: <Bakery/>
  },
  {
    path: "/addEmployee",
    element: <NewEmployeeForm/>
  },
  {
    path: "/editEmployee/:employeeId",
    element: <EditEmployeeForm/>
  },
  {
    path: "/employeeDetails/:employeeId",
    element: <EmployeeDetails/>
  }
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);

reportWebVitals();
